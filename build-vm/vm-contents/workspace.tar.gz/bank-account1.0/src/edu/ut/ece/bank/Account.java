package edu.ut.ece.bank;

//import junit.framework.TestCase;


/*
 * Store standard account information
 */
public class Account extends BankInfo {
	public String account;
	public double checking = 100;
	public double yRate = 0.01;
	// added field
		public double saving = 100;
	public Account(String a) {
		account = a;
	}

	// get account balance amount
	public double getAmnt() {
		return checking;
	}

	// withdraw from the account
	public double withdraw(double v) {
		if (checking >= v) {
			checking = checking - v;
			return v;
		} else
			return 0;
	}

	// deposit to the account
	public void deposit(double v) {
		checking = checking + v;
	}
}
