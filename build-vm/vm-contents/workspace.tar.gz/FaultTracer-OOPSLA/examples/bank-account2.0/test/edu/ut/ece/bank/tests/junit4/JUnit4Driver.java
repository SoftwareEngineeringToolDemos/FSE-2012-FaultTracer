package edu.ut.ece.bank.tests.junit4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({ JUnit4Tests.class })
public class JUnit4Driver {
}