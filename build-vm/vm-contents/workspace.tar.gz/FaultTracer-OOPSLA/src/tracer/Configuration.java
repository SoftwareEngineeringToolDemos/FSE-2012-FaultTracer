package tracer;

public class Configuration {
	public static boolean considerOverriden =true;
	public static boolean isMac = false;//todo
	public static boolean traceCallRelation=false;
	public static boolean traceField=true;
}
