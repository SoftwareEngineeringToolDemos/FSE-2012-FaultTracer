package tracer.genBat;

public class GenTestRun {
	public static void main(String[] args){
		
		
		
	}

}
